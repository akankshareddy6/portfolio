from flask import Flask,render_template
app=Flask(__name__)

@app.route('/',methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/inner-page',methods=['GET'])
def innerpage():
    return render_template('inner-page.html')

@app.route('/portfolio_details',methods=['GET'])
def portfolio_details():
    return render_template('portfolio_details.html')


if __name__=='__main__':
    app.run(debug=True)